<?php 
include 'config.php';
session_start();
	if($_SESSION['password']=="")
	
	{
		echo "<script>window.location='login.php?msg=please login'</script>";
	}

$name=$_POST['name'];
mysqli_query($conn,"insert into `company` (`name`) values ('$name')");
$company_id = mysqli_insert_id($conn);
$channelname = $_POST['channelname'];
foreach($channelname as $channelname1){
	mysqli_query($conn,"insert into `company_data` (`company_id`,`channel_name`)values('$company_id','$channelname1')");
}

echo "<script>window.location='companyview.php'</script>";

?>