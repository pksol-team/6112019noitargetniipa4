<?php 
include 'config.php';
session_start();
	if($_SESSION['password']=="")
	
	{
		echo "<script>window.location='login.php?msg=please login'</script>";
	}

$uname=$_POST['uname'];
$password=$_POST['password'];
$email=$_POST['email'];
$text=$_POST['text'];






mysqli_query($conn,"insert into user (uname,password,email,text) values ('$uname','$password','$email','$text')");
echo "<script>window.location='userview.php'</script>";

?>