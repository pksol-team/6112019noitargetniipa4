<?php 
$conn = mysqli_connect("localhost","appzitoc_demo","appzitoc_demo","appzitoc_demo");


?>