
									function run(filtertype){ 
									
									if(filtertype=='price'){
			$("#logindiv").css("display", "block");
									}else if(filtertype=='sku'){
										$("#logindiv1").css("display", "block");
									}else if(filtertype=='shipping'){
										$("#logindiv2").css("display", "block");
									}
		}function runX(filtertype){   
									
									if(filtertype=='price'){
			$("#despatch_1").css("display", "block");
									}else if(filtertype=='sku'){
										$("#despatch_2").css("display", "block");
									}else if(filtertype=='shipping'){
										$("#despatch_3").css("display", "block");
		}}
									function runF(filtertype){ 
									
									if(filtertype=='price'){
			$("#logindiv_progress").css("display", "block");
									}else if(filtertype=='sku'){
										$("#logindiv_progress_1").css("display", "block");
									}else if(filtertype=='shipping'){
										$("#logindiv_progress_2").css("display", "block");
									}
		}
		function ImportForm(){
			$("#importform").css("display", "block");
		}
		function closeTab(){
			
			$("#logindiv").css("display","none");
			$("#logindiv1").css("display","none");
			$("#logindiv2").css("display","none");
			$("#importform").css("display","none");
			$("#despatch_1").css("display","none");
			$("#despatch_2").css("display","none");
			$("#despatch_3").css("display","none");
			$("#logindiv_progress").css("display","none");
			$("#logindiv_progress_1").css("display","none");
			$("#logindiv_progress_2").css("display","none");
			$("#addusertab1").css("display","none");
			
		}
		
//----------------------------------
									function FormStuff() {
									
									var print_type = document.getElementById("print_type").value;
										if(print_type == 'invoice'){
									 document.print.action = "invoice.php";
									 document.getElementById("selectstatus").innerHTML = "";	
									
										}
										else if(print_type == 'returnsform'){
											
										 document.print.action = "returnsform.php";
										
								document.getElementById("selectstatus").innerHTML = "";
								
										}
										
										else if(print_type == 'picking'){
											
										 document.print.action = "picking_list.php";
										
								document.getElementById("selectstatus").innerHTML = "";										
										}
										else if(print_type == 'addnote'){
											
										 document.print.action = "addnotesubmit.php";
										
								document.getElementById("selectstatus").innerHTML = "";
								 $('#selectstatus').append('<input name="addnote" placeholder="Enter Note Here" type="text" class="form-control selectst"><br>');
										}
										else if(print_type == 'export'){
											
										 document.print.action = "export.php";
										
								document.getElementById("selectstatus").innerHTML = "";										
										}
										else if(print_type == 'jobsheet'){
											
										 document.print.action = "jobsheet.php";
										
								document.getElementById("selectstatus").innerHTML = "";										
										}else if(print_type == 'makedespatched'){
											
										 document.print.action = "makedespatched.php";
										
								document.getElementById("selectstatus").innerHTML = "";
										 $('#selectstatus').append('<select name="despatch" type="text" class="form-control selectst"><option value="">Select Status</option><option value="0">Remove As Despatched</option><option value="shipped">Make As Despatced</option></select><br>');
										}
										else if(print_type == 'flag'){
											
										 document.print.action = "flagsubmit.php";
										
								document.getElementById("selectstatus").innerHTML = "";
										 $('#selectstatus').append('<select name="flag" type="text" class="form-control selectst"><option value="">Select Flag Status</option><option value="holdorder">Hold Order</option><option value="urgent">Urgent</option></select><br>');
										}
										
										else if(print_type == 'status'){
											
										 document.print.action = "status_change.php";
										 document.getElementById("selectstatus").innerHTML = "";
										  $('#selectstatus').append('<select name="status" type="text" class="form-control selectst"><option value="">Select Status</option><option value="new">New</option><option value="inprogress">In progress</option><option value="shipped">Shipped</option ><option value="close">Close</option></select><br>');
																		
										}
										else{
											document.print.action = "#";
											document.getElementById("selectstatus").innerHTML = "";	
										}
									}
									function FormStuffUser(){
									document.print.action = "adduser.php";
									}
									function Note(){
									document.print.action = "addnotesubmit.php";
									}
									function Export(){
									document.print.action = "export.php";
									document.getElementById('form1').submit();
									
									}
									function Export_progress(){
									document.print1.action = "export.php";
									document.getElementById('form2').submit();
									
									}
									function Export_despatch(){
									document.print2.action = "export.php";
									document.getElementById('form3').submit();
									
									}
									
									
									//------------------------tab-2---------------------------------------------------------------------
								function FormStuff1() {
									
									var print_type1 = document.getElementById("print_type1").value;
										if(print_type1 == 'invoice'){
									 document.print1.action = "invoice.php";
									 document.getElementById("selectstatus1").innerHTML = "";	
									
										}
										else if(print_type1 == 'returnsform'){
											
										 document.print1.action = "returnsform.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
								
										}
										
										else if(print_type1 == 'picking'){
											
										 document.print1.action = "picking_list.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}
										else if(print_type1 == 'addnote'){
											
										 document.print1.action = "addnotesubmit.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
								 $('#selectstatus1').append('<input name="addnote" placeholder="Enter Note Here" type="text" class="form-control selectst"><br>');
										}
										else if(print_type1 == 'export'){
											
										 document.print1.action = "export.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}
										else if(print_type1 == 'jobsheet'){
											
										 document.print1.action = "jobsheet.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}else if(print_type1 == 'makedespatched'){
											
										 document.print1.action = "makedespatched.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
										 $('#selectstatus1').append('<select name="despatch" type="text" class="form-control selectst"><option value="">Select Status</option><option value="0">Remove As Despatched</option><option value="shipped">Make As Despatced</option></select><br>');
										}
										else if(print_type1 == 'flag'){
											
										 document.print1.action = "flagsubmit.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
										 $('#selectstatus1').append('<select name="flag" type="text" class="form-control selectst"><option value="">Select Flag Status</option><option value="holdorder">Hold Order</option><option value="urgent">Urgent</option></select><br>');
										}
										
										else if(print_type1 == 'status'){
											
										 document.print1.action = "status_change.php";
										 document.getElementById("selectstatus1").innerHTML = "";
										  $('#selectstatus1').append('<select name="status" type="text" class="form-control selectst"><option value="">Select Status</option><option value="new">New</option><option value="inprogress">In progress</option><option value="shipped">Shipped</option ><option value="close">Close</option></select><br>');
																		
										}
										else{
											document.print1.action = "#";
											document.getElementById("selectstatus1").innerHTML = "";	
										}
									}
									//-------------------------tab3--------------------------------------------------------------
									function FormStuff2() {
									
									var print_type2 = document.getElementById("print_type2").value;
										if(print_type2 == 'invoice'){
									 document.print2.action = "invoice.php";
									 document.getElementById("selectstatus2").innerHTML = "";	
									
										}else if(print_type2 == 'picking'){
											
										 document.print2.action = "picking_list.php";
										
								document.getElementById("selectstatus2").innerHTML = "";										
										}
										else if(print_type2 == 'export'){
											
										 document.print2.action = "export.php";
										
								document.getElementById("selectstatus2").innerHTML = "";										
										}
										else if(print_type2 == 'returnsform'){
											
										 document.print2.action = "returnsform.php";
										
								document.getElementById("selectstatus2").innerHTML = "";										
										}
										
										else if(print_type2 == 'addnote'){
											
										 document.print2.action = "addnotesubmit.php";
										
								document.getElementById("selectstatus2").innerHTML = "";
								 $('#selectstatus2').append('<input name="addnote" placeholder="Enter Note Here" type="text" class="form-control selectst"><br>');
										}
										else if(print_type2 == 'flag'){
											
										 document.print2.action = "flagsubmit.php";
										
								document.getElementById("selectstatus2").innerHTML = "";
										 $('#selectstatus2').append('<select name="flag" type="text" class="form-control selectst"><option value="">Select Flag Status</option><option value="holdorder">Hold Order</option><option value="urgent">Urgent</option></select><br>');
										}
										
										else if(print_type2 == 'jobsheet'){
											
										 document.print2.action = "jobsheet.php";
										
								document.getElementById("selectstatus2").innerHTML = "";										
										}else if(print_type2 == 'makedespatched'){
											
										 document.print2.action = "makedespatched.php";
										
								document.getElementById("selectstatus2").innerHTML = "";
										 $('#selectstatus2').append('<select name="despatch" type="text" class="form-control selectst"><option value="">Select Status</option><option value="0">Remove As Despatched</option><option value="shipped">Make As Despatced</option></select><br>');
										}
										
										else if(print_type2 == 'status'){
											
										 document.print2.action = "status_change.php";
										 document.getElementById("selectstatus2").innerHTML = "";
										  $('#selectstatus2').append('<select name="status" type="text" class="form-control selectst"><option value="">Select Status</option><option value="new">New</option><option value="inprogress">In progress</option><option value="shipped">Shipped</option ><option value="close">Close</option></select><br>');
																		
										}
										else{
											document.print2.action = "#";
											document.getElementById("selectstatus2").innerHTML = "";	
										}
									}
									
									function FormStuffUser2(){
										document.print2.action = "adduser.php";
									}
									function Note3(){
										document.print2.action = "addnotesubmit.php";
									}
									
									
									
									function FormStuffUser1(){
										document.print_progress.action = "adduser.php";
									}
									function Note2(){
										document.print_progress.action = "addnotesubmit.php";
									}
									function addUser(orderid){
										
										$('#addusertab1 #order_id').val(orderid);
										
										$('#addusertab1 #order_id'). attr("type","hidden");
										$("#addusertab1").css("display", "block");
										
										$('#user_name').focus();
									}
									
									
									