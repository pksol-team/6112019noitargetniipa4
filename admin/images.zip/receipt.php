<html id="pdf" lang="en"><!--<![endif]--><!-- BEGIN HEAD --><head>
        <meta charset="utf-8">
        <title>Project</title>        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=60" name="viewport">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="" name="description">
        <meta content="" name="author">
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css">
        <link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css">
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="../assets/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css">
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="../assets/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css">
        <link href="../assets/global/css/plugins-md.min.css" rel="stylesheet" type="text/css">
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="../assets/layouts/layout3/css/layout.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/layouts/layout3/css/themes/default.min.css" rel="stylesheet" type="text/css" id="style_color">
        <link href="../assets/layouts/layout3/css/custom.min.css" rel="stylesheet" type="text/css">
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico"> </head>
    <!-- END HEAD -->

    <body  class="page-container-bg-solid page-md a4" cz-shortcut-listen="true">
        <!-- BEGIN HEADER -->
        <style>@page { size: A5 landscape }</style>
        <!-- END HEADER -->
        <!-- BEGIN CONTAINER -->
       <div  class="container-fluid ">
                        <!-- BEGIN PAGE BREADCRUMBS -->
                                                <!-- END PAGE BREADCRUMBS -->
                        <!-- BEGIN PAGE CONTENT INNER -->
                        <div class="page-content-inner ">
                           
                            <div class="row">
                                <div class="col-md-12"  id="HTMLtoPDF">
								
                                <div class="portlet light">
								<div class="row">
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								<div class="col-md-3 ">
								<div class="col-md-6 pull-left">Band Supplies<br>
7 Hunslet Road<br>
Leeds, West Yorkshire<br>
LS10 1JQ </div>
								<div class="pull-right col-md-4"><img src="ppi.jpg" class="img pull-right"></div>
								<div class="col-md-2 pull-left"></div>
								<div class="col-md-8">
								<small><b>(SKU: 90g_DL_Window_White_100//90g_DL_PLN_White_100)</b></small><br>
								<small><b>https://www.postage-solutions.co.uk</b></small><br>
<small>Returns: Unit 7 Carlton Court, Grainger Road, Essex – SS2 5BZ.</small>
								
								</div>
								</div>
								
								
								</div>
                               
                                </div>
                                </div>
                            </div>
                           <style> 
						   .a4{
							   width: 29cm;
    min-height: 29.7cm;
						   }
						  
						  .img{
							 height: 200px; 
							  
						  }
						  .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
    position: relative;
    min-height: 1px;
     padding-left: 0px; 
    padding-right: 0px;
}
@media (min-width: 992px){
.col-md-6 {
    width: 62%;
}
.col-md-3{
	width: 50%;
	height:211.99px;
	padding:6px 6px 6px 6px;
	
	
}
.col-md-8 {
       width: 68%;
   margin-top: 46px;
margin-left: 0px;
  word-break: break-all;
}
.col-md-4{
	    width: 16.33333%;
}
}
.page-content {
    background: #eff3f8;
    padding: 15px 0;
    width: 35cm;
}
.col-md-8{
	overflow-wrap: break-word;
}
					   </style>
                        </div>
                        <!-- END PAGE CONTENT INNER -->
                    </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
		
    
        <!-- BEGIN CORE PLUGINS -->
        <script src="../assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="../assets/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="../assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="../assets/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="../assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="../assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="../assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
    

</body><footer> 
		<div id="content">
     <h3>Hello, this is a H3 tag</h3>

    <p>A paragraph</p>
</div>
<div id="editor"></div>
<button id="cmd" onclick="HTMLtoPDF();">generate PDF</button>



<script src="js/jspdf.js"></script>
	<script src="js/jquery-2.1.3.js"></script>
	<script src="js/pdfFromHTML.js"></script>
	
		<!-- Scripts in development mode -->
		
		</footer></html>