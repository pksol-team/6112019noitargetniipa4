<!DOCTYPE html>
<?php
error_reporting(0);
session_start();
if($_SESSION['password']==''){
	echo "<script>window.location='login.php'</script>";
}
 include 'config.php';
 ?>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.3.6
Version: 4.5.6
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
       <?php include 'title.php';?>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="../assets/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="../assets/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="../assets/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="../assets/layouts/layout3/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/layouts/layout3/css/themes/default.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="../assets/layouts/layout3/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->
<?php include 'popups.php';?>
    <body class="page-container-bg-solid page-md">
        <!-- BEGIN HEADER -->
		 
        <div class="page-header">
            <!-- BEGIN HEADER TOP -->
            <div class="page-header-top">
                <div class="container-fluid">
                    <!-- BEGIN LOGO -->
                    <div class="page-logo">
                        <a href="index.html">
                            <img src="../assets/layouts/layout3/img/logo-default.jpg" alt="logo" class="logo-default">
                        </a>
                    </div>
                    <!-- END LOGO -->
                    <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                    <a href="javascript:;" class="menu-toggler"></a>
                    <!-- END RESPONSIVE MENU TOGGLER -->
                    <!-- BEGIN TOP NAVIGATION MENU -->
                   <?php include 'top.php' ?>
                    <!-- END TOP NAVIGATION MENU -->
                </div>
            </div>
            <!-- END HEADER TOP -->
            <!-- BEGIN HEADER MENU -->
            <?php include 'menu.php';?>
            <!-- END HEADER MENU -->
        </div>
        <!-- END HEADER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <!-- BEGIN PAGE HEAD-->
                <div class="page-head">
                    <div class="container-fluid">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Order Datatables
                                <small>Order datatable </small>
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                        <!-- BEGIN PAGE TOOLBAR -->
                       
                        <!-- END PAGE TOOLBAR -->
						
						
                    </div>
                </div>
                <!-- END PAGE HEAD-->
                <!-- BEGIN PAGE CONTENT BODY -->
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- BEGIN PAGE BREADCRUMBS -->
                       <?php //include 'siteurl.php';?>
                        <!-- END PAGE BREADCRUMBS -->
                        <!-- BEGIN PAGE CONTENT INNER 
						 <div class="row">
                                <div class="col-md-12">
								<div class="portlet light">
								dfsd
								</div>
								</div>
								</div>-->
                        <div class="page-content-inner">
                          
                            <div class="row">
                                <div class="col-md-12">
                                <div class="portlet light">
								<ul class="nav nav-tabs">
										 <li class="active" >
                                            <a href="#tab_1_1" data-toggle="tab"><b> New </b></a>
                                        </li>
										  <li>
                                            <a href="#tab_1_2" data-toggle="tab"> <b>In Progress </b></a>
                                        </li>
										 <li>
                                            <a href="#tab_1_3" data-toggle="tab"><b> Despatched </b></a>
                                        </li>
                                       
                                   </ul>
                                    <!-- BEGIN EXAMPLE TABLE PORTLET-->
									<div class="tab-content">
									 <div class="tab-pane fade active in" id="tab_1_1">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            
                                           
											<div class="row col-md-6">
											
                                                <div class="pull-left">
												<div class="btn-group">
                                                   <select class="form-control custom-select" id="print_type" onchange="FormStuff();">
												   <option value="select">Tools</option>
												   <option value="flag">Add Flag</option>
												   <option value="jobsheet">Print Job-Sheet</option>
												   <option value="invoice">Print Invoice</option>
												   <option value="picking">Print Picking List</option>
												   <option value="returnsform">Returns Form</option>
												   <option value="status">Change Status</option>
												   
												   <option value="makedespatched">Create SheepMent</option>
												
												   </select>
                                                </div>
												<div class="btn-group">
                                                  <button type="button" id="sample_editable_1_new" onclick="document.getElementById('form1').submit()" class="btn sbold green"> OK
                                                      
                                                    </button>
                                                </div>
												 <div class="btn-group">
                                                    <button type="button" onclick="ImportForm();" id="sample_editable_1_new" class="btn sbold red">Import</button> 
                                                </div> 
                                                <div class="btn-group"><button  onclick="Export();" id="sample_editable_1_new" class="btn sbold blue"> Export</button></div>
												<div class="btn-group"><button id="sample_editable_1_new" class="btn yellow-crusta"> Create Order</button></div>
                                            </div>
                                            </div>
											 <div class="row col-md-6">
                                               
											   <div class="pull-right">
											   
											   <div class="form-group">
											   <select class="form-control fltr" name="filter_name" id="filter_name" onchange="run(this.value);">
											   <option >Filter</option>
											   <option value="shipping">Shipping</option>
											   <option value="price">Price</option>
											   <option value="sku">SKU</option>
											   </select>
											  
											   
											  </div>
											   </div>
                                          
											   
											   
											   
                                            </div>
                                        </div>
                                    </div>
									<script>
									
									</script>
									<form  method="post" id="form1" name="print" action="/">
									<div id="selectstatus"></div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_2">
                                        <thead>
                                            <tr>
                                              <th>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="group-checkable" data-set="#sample_2 .checkboxes" />
                                                        <span></span>
                                                    </label>
                                                </th>  
                                                <th >no</th>
                                                <th >Logo</th>
                                                <th >order Id</th>
                                                <th >Date</th>
                                                <th >Customer</th>
                                                <th >PostCode</th>
												<th >SKU</th>
												<th >QTY</th>
												<th >Shipping</th>
												<th >Total</th>
												<th ><div class="">Status</div></th>
											
												 <th ><div class="statuss">-</div></th>
												 
                                                
                                             </tr>
                                        </thead>
                                        <tbody>
										    <?php
						                       $sn=0;
											   
											 
											    $from = $_GET['from'];
											   $to = $_GET['to'];
											   $skuword = $_GET['skuword'];
											    $shippingword = $_GET['shippingword'];
						                     
											   if(!empty($from) or !empty($to)){
												$sql_011=mysqli_query($conn,"SELECT * FROM `order_data` where status='new' AND `price` between '$from' AND '$to'");   
											   }elseif(!empty($skuword)){
												 $sql_011=mysqli_query($conn,"SELECT * FROM `order_data` where status='new' AND CONCAT(UPPER(sku),UPPER(custom_label)) LIKE UPPER('%$skuword%')");    
											   }elseif(!empty($shippingword)){
												   $sql_011=mysqli_query($conn,"SELECT * FROM `order_data` where status='new' AND CONCAT(UPPER(delivery_service),UPPER(ship_service_level)) LIKE UPPER('%$shippingword%')"); 
											   }else{
												   $sql_011=mysqli_query($conn,"SELECT * FROM `order_data` where status='new' ");  
											   }
						                       
						                       while($data_011=mysqli_fetch_assoc($sql_011))
						                       {
							                     $sn++;
							                     $id=$data_011['id'];
													$order_no_check[] = $data_011['sales_r_no'];
													$sale_order_no =  $data_011['sales_r_no'];
													
							                     $name=$data_011['name'];
												 if(in_array("$sale_order_no",array_slice($order_no_check,1))){
													 
												 
		                                     ?>
												 <?php } else { ?>
                                             <tr class="odd gradeX">
                                               <td>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" name="company_order_id[]" value="<?php echo $id;?>" class="checkboxes"  />
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo $sn;?></td>
												<?php 
												
												$c_id = $data_011['channel_id'];
												$c_name_data = mysqli_query($conn,"select * from `channel` where `id`='$c_id'");
												$data_c_name = mysqli_fetch_assoc($c_name_data);
												?>
                                                <td><img src="images/<?php echo $data_c_name['file'];?>" title="<?php echo $data_c_name['name'];?>" width="30px" height="30px"></td>
                                                <td  class=""><div class="tooltip1"><?php echo $data_011['sales_r_no'];?><div class="">
												 <div class="portlet light">
												 <div class="row">
												 <div class="col-md-12 col-sm-12">
                                                        <div class="portlet yellow-crusta box">
                                                            <div class="portlet-title">
                                                                <div class="caption">
                                                                    <i class="fa fa-cogs"></i>Order Details </div>
                                                                
                                                            </div>
                                                            <div class="portlet-body">
                                                                <div class="row static-info">
                                                                    <center><div class="col-md-8 name">
																	
																	<h4>OrderNo.<?php echo $data_011['sales_r_no'];?></h4>
																	</div>
                                                                   </center>
                                                                </div>
																<hr class="custome_hr">
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Date &amp; Time: </div>
                                                                    <div class="col-md-7 value"> Dec 27, 2013 7:16:25 PM </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Status: </div>
                                                                    <div class="col-md-7 value">
                                                                        <span class="label label-success"> Closed </span>
                                                                    </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Grand Total: </div>
                                                                    <div class="col-md-7 value"> $175.25 </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Payment Information: </div>
                                                                    <div class="col-md-7 value"> Credit Card </div>
                                                                </div>
																<hr class="custome_hr">
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Date &amp; Time: </div>
                                                                    <div class="col-md-7 value"> Dec 27, 2013 7:16:25 PM </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Status: </div>
                                                                    <div class="col-md-7 value">
                                                                        <span class="label label-success"> Closed </span>
                                                                    </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Grand Total: </div>
                                                                    <div class="col-md-7 value"> $175.25 </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Payment Information: </div>
                                                                    <div class="col-md-7 value"> Credit Card </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
												 </div>
												 </div>
												</div></div>
												</td>
												
												
												
                                                <td><?php  if(!empty($data_011['sale_date'])){echo $data_011['sale_date'];}else{echo $data_011['payments_date'];}?></td>
												
                                                <td class=""><div class=""><?php if(!empty($data_011['buyer_name'])){echo $data_011['buyer_name'];} ?>
												</div>
												</td>
												
												
                                                
												<td >
												<div class=""><?php if(!empty($data_011['buyer_postcode'])){echo $data_011['buyer_postcode'];}else{echo $data_011['ship_postal_code'];} ?></div>
												</td>
												<td><?php if(!empty($data_011['custom_label'])){echo $data_011['custom_label'];}else{echo $data_011['sku'];} ?></td>
												 <td class=""><?php if(!empty($data_011['quantity'])){echo $data_011['quantity'];}else{echo $data_011['quantity_to_ship'];} ?>
												
												</td>
												<td class=""><?php if(!empty($data_011['delivery_service'])){echo $data_011['delivery_service'];}else{echo $data_011['ship_service_level'];} ?>
												
												</td>
												 <td>-</td>
												 <td> <?php if($data_011['status']=='new') { ?>
											   <button type="button" class="label label-info">New</button>
											   <?php } elseif($data_011['status']=='inprogress') { ?>
											    <button type="button" class="label label-warning">In progress</button>
											   <?php } elseif($data_011['status']=='shipped' )  { ?>
											   <button type="button" class="label label-success">Shipped</button>
											   <?php } elseif($data_011['status']=='close') { ?>
											    <button type="button" class="label label-danger">Close</button>
											   <?php } ?>
											   <br>
											   <?php if($data_011['flag']=='holdorder') { ?>
											    <button type="button" class="label label-warning"> <span  class="icon-flag"></span>hold-order</button>
											   <?php }elseif($data_011['flag']=='urgent'){ ?>
											    <button type="button" class="label label-danger"> <span  class="icon-flag"></span>urgent</button>
											   <?php } ?>
											   </td>
											   
												 <td> 
											  
																	<div class="btn-group ">
																	
                                                                      
                                                                        <button onclick="addUser(this.value);" value="<?php echo $id; ?>" type="button" class="fa fa-user green1" ></button>
                                                                      <button type="button" class="fa fa-edit notee"></button>
                                                                        <button type="button" class="fa fa-truck truck"></button>
																	
															
                                                                    </div><br><div id="u">
																	<?php if(!empty($data_011['user'])) { ?>
																	<button type="button" class="label label-warning"> <span  class="icon-user b11"></span>&nbsp;<span class="b11">
																	<?php
																	$user_id =  $data_011['user'];
																	$user_data1 = mysqli_query($conn,"select * from `user` where `uid`='$user_id'");
																			$data_user1 = mysqli_fetch_assoc($user_data1);
																			echo $data_user1['uname'];
																	?></span></button>
																	<?php } ?>
																	</div>
																	</td>
                                               
                                                
                                               
                                               
                                              </tr>
                                            	  <?php  } ?>
                                            	  <?php  } ?>
                                        </tbody>
                                    </table>
									</form>
                                    </div>
									<div class="tab-pane fade" id="tab_1_2">
                                     <div class="table-toolbar">
                                        <div class="row">
                                           <div class="row col-md-6">
											
                                                
												<div class="btn-group">
                                                   <select class="form-control custom-select" id="print_type1" onchange="FormStuff1();">
												   <option value="select">Tools</option>
												   <option value="flag">Add Flag</option>
												   <option value="jobsheet">Print Job-Sheet</option>
												   <option value="invoice">Print Invoice</option>
												   <option value="picking">Print Picking List</option>
												   <option value="returnsform">Returns Form</option>
												   <option value="status">Change Status</option>
												   
												   <option value="makedespatched">Create SheepMent</option>
												
												   </select>
                                                </div>
												<div class="btn-group">
                                                  <button type="button" id="sample_editable_1_new" onclick="document.getElementById('form2').submit()" class="btn sbold green"> OK
                                                      
                                                    </button>
                                                </div>
												 <div class="btn-group">
                                                    <button type="button" onclick="ImportForm();" id="sample_editable_1_new" class="btn sbold red">Import</button> 
                                                </div> 
                                                <div class="btn-group"><button  onclick="Export_progress();" id="sample_editable_1_new" class="btn sbold blue"> Export</button></div>
												<div class="btn-group"><button id="sample_editable_1_new" class="btn yellow-crusta"> Create Order</button></div>
                                            </div>
                                            <div class="row col-md-6">
                                               <div class=" pull-right">
											   <div class="form-group">
											   <select class="form-control fltr" name="filter_name" id="filter_name" onchange="runF(this.value);">
											   <option >Filter</option>
											   <option value="shipping">Shipping</option>
											   <option value="price">Price</option>
											   <option value="sku">SKU</option>
											   </select>
											   <input type="text" value="#tab_1_3" hidden>
											   </div>
											
											   </div>
											   
											   
											   
											   
                                            </div>
                                        </div>
                                    </div>
									<script>
									
									</script>
									<form method="post" id="form2" name="print1" action="/">
									<div id="selectstatus1"></div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                              <th>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                                        <span></span>
                                                    </label>
                                                </th>  
                                                <th >no</th>
                                                <th >Logo</th>
                                                <th >order Id</th>
                                                <th >Date</th>
                                                <th >Customer</th>
                                                <th >PostCode</th>
												<th >SKU</th>
												<th >QTY</th>
												<th >Shipping</th>
												<th >Total</th>
												<th ><div class="">Status</div></th>
											
												 <th ><div class="statuss">-</div></th>
												 
                                               
                                               
                                               
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
										    <?php
						                       $sn=0;
											   
											 $from_progress = $_GET['from_progress'];
											   $to_progress = $_GET['to_progress'];
											   $skuword_progress = $_GET['skuword_progress'];
											    $shippingword_progress = $_GET['shippingword_progress'];
						                       
											   if(!empty($from_progress) or !empty($to_progress)){
												$sql_013=mysqli_query($conn,"SELECT * FROM `order_data` where status='inprogress' AND `price` between '$from_progress' AND '$to_progress'");   
											   }elseif(!empty($skuword_progress)){
												 $sql_013=mysqli_query($conn,"SELECT * FROM `order_data` where status='inprogress' AND CONCAT(UPPER(sku),UPPER(custom_label)) like UPPER('%$skuword_progress%')");    
											   }elseif(!empty($shippingword_progress)){
												   $sql_013=mysqli_query($conn,"SELECT * FROM `order_data` where status='inprogress' AND CONCAT(UPPER(delivery_service),UPPER(ship_service_level)) like UPPER('%$shippingword_progress%')");
												   
											   }else{
												   $sql_013=mysqli_query($conn,"SELECT * FROM `order_data` where status='inprogress' ");  
											   }
						                       //$sql_013=mysqli_query($conn,"SELECT * FROM `order_data` where status='inprogress'");
						                       while($data_0011=mysqli_fetch_assoc($sql_013))
						                       {
							                     $sn++;
							                     $id=$data_0011['id'];
							
							                     $name=$data_0011['name'];
		                                     ?>
                                            <tr class="odd gradeX">
                                               <td>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" name="company_order_id[]" value="<?php echo $id;?>" class="checkboxes"  />
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo $sn;?></td>
												<?php 
												
												$c_id = $data_0011['channel_id'];
												$c_name_data = mysqli_query($conn,"select * from `channel` where `id`='$c_id'");
												$data_c_name = mysqli_fetch_assoc($c_name_data);
												?>
                                                <td><img src="images/<?php echo $data_c_name['file'];?>" title="<?php echo $data_c_name['name'];?>" width="30px" height="30px"></td>
                                                 <td  class=""><div class="tooltip1"><?php echo $data_0011['sales_r_no'];?><div class="">
												 <div class="portlet light">
												 <div class="row">
												 <div class="col-md-12 col-sm-12">
                                                        <div class="portlet yellow-crusta box">
                                                            <div class="portlet-title">
                                                                <div class="caption">
                                                                    <i class="fa fa-cogs"></i>Order Details </div>
                                                                
                                                            </div>
                                                            <div class="portlet-body">
                                                                <div class="row static-info">
                                                                    <center><div class="col-md-8 name">
																	
																	<h4>OrderNo.<?php echo $data_0011['sales_r_no'];?></h4>
																	</div>
                                                                   </center>
                                                                </div>
																<hr class="custome_hr">
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Date &amp; Time: </div>
                                                                    <div class="col-md-7 value"> Dec 27, 2013 7:16:25 PM </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Status: </div>
                                                                    <div class="col-md-7 value">
                                                                        <span class="label label-success"> Closed </span>
                                                                    </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Grand Total: </div>
                                                                    <div class="col-md-7 value"> $175.25 </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Payment Information: </div>
                                                                    <div class="col-md-7 value"> Credit Card </div>
                                                                </div>
																
                                                            </div>
                                                        </div>
                                                    </div>
												 </div>
												 </div>
												</div></div>
												</td>
                                                <td><?php  if(!empty($data_0011['sale_date'])){echo $data_0011['sale_date'];}else{echo $data_0011['payments_date'];}?></td>
												
                                                <td class=""><div class=""><?php if(!empty($data_0011['buyer_name'])){echo $data_0011['buyer_name'];} ?>
												</div>
												</td>
												
												
                                                
												<td >
												<div class=""><?php if(!empty($data_0011['buyer_postcode'])){echo $data_0011['buyer_postcode'];}else{echo $data_0011['ship_postal_code'];} ?></div>
												</td>
												<td><?php if(!empty($data_0011['custom_label'])){echo $data_0011['custom_label'];}else{echo $data_0011['sku'];} ?></td>
												 <td class=""><?php if(!empty($data_0011['quantity'])){echo $data_0011['quantity'];}else{echo $data_0011['quantity_to_ship'];} ?>
												
												</td>
												<td class=""><?php if(!empty($data_0011['delivery_service'])){echo $data_0011['delivery_service'];}else{echo $data_0011['ship_service_level'];} ?>
												
												</td>
												 <td>-</td>
												 <td> <?php if($data_0011['status']=='new') { ?>
											   <button type="button" class="label label-info">New</button>
											   <?php } elseif($data_0011['status']=='inprogress') { ?>
											    <button type="button" class="label label-warning">In progress</button>
											   <?php } elseif($data_0011['status']=='shipped' )  { ?>
											   <button type="button" class="label label-success">Shipped</button>
											   <?php } elseif($data_0011['status']=='close') { ?>
											    <button type="button" class="label label-danger">Close</button>
											   <?php } ?>
											   <br>
											   <?php if($data_0011['flag']=='holdorder') { ?>
											    <button type="button" class="label label-warning"> <span  class="icon-flag"></span>hold-order</button>
											   <?php }elseif($data_0011['flag']=='urgent'){ ?>
											    <button type="button" class="label label-danger"> <span  class="icon-flag"></span>urgent</button>
											   <?php } ?>
											   </td>
											   
												 <td> 
											  
																	<div class="btn-group ">
																	
                                                                      
                                                                        <button onclick="addUser(this.value);" value="<?php echo $id; ?>" type="button" class="fa fa-user green1" ></button>
                                                                      <button type="button" class="fa fa-edit notee"></button>
                                                                        <button type="button" class="fa fa-truck truck"></button>
																	
															
                                                                    </div><br>
																	<?php if(!empty($data_0011['user'])) { ?>
																	<button type="button" class="label label-warning"> <span  class="icon-user b11"></span>&nbsp;<span class="b11"><?php
																	$user_id =  $data_0011['user'];
																	$user_data1 = mysqli_query($conn,"select * from `user` where `uid`='$user_id'");
																			$data_user1 = mysqli_fetch_assoc($user_data1);
																			echo $data_user1['uname'];
																	?></span></button>
																	<?php } ?>
																	
																	</td>
                                               
                                                
                                               
                                               
                                              </tr>
                                            	  <?php  } ?>
                                        </tbody>
                                    </table>
									
									</form>
									
									<!-- tab 3 end--></div>
									<link href="custom.css" rel="stylesheet" type="text/css" />
									<div class="tab-pane fade" id="tab_1_3">
                                     <div class="table-toolbar">
                                        <div class="row">
                                            <div class="row col-md-6">
											
                                                
												<div class="btn-group">
                                                   <select class="form-control custom-select" id="print_type2" onchange="FormStuff2();">
												   <option value="select">Tools</option>
												   <option value="flag">Add Flag</option>
												   <option value="jobsheet">Print Job-Sheet</option>
												   <option value="invoice">Print Invoice</option>
												   <option value="picking">Print Picking List</option>
												   <option value="returnsform">Returns Form</option>
												   <option value="status">Change Status</option>
												   
												   <option value="makedespatched">Create SheepMent</option>
												
												   </select>
                                                </div>
												<div class="btn-group">
                                                  <button type="button" id="sample_editable_1_new" onclick="document.getElementById('form3').submit()" class="btn sbold green"> OK
                                                      
                                                    </button>
                                                </div>
												 <div class="btn-group">
                                                    <button type="button" onclick="ImportForm();" id="sample_editable_1_new" class="btn sbold red">Import</button> 
                                                </div> 
                                                <div class="btn-group"><button  onclick="Export_despatch();" id="sample_editable_1_new" class="btn sbold blue"> Export</button></div>
												<div class="btn-group"><button id="sample_editable_1_new" class="btn yellow-crusta"> Create Order</button></div>
                                            </div>
                                            <div class="row col-md-6">
                                               <div class=" pull-right">
											   <div class="form-group">
											   <select class="form-control fltr" name="filter_name" id="filter_name" onchange="runX(this.value);">
											   <option >Filter</option>
											   <option value="shipping">Shipping</option>
											   <option value="price">Price</option>
											   <option value="sku">SKU</option>
											   </select>
											   <input type="text" value="#tab_1_2" hidden>
											   </div>
											
											   </div>
											   
											   
											   
											   
                                            </div>
                                        </div>
                                    </div>
									<script>
									
									</script>
									<form  method="post" id="form3" name="print2" action="/">
									<div id="selectstatus2"></div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_3">
                                        <thead>
                                            <tr>
                                              <th>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="group-checkable" data-set="#sample_3 .checkboxes" />
                                                        <span></span>
                                                    </label>
                                                </th>  
                                                <th >no</th>
                                                <th >Logo</th>
                                                <th >order Id</th>
                                                <th >Date</th>
                                                <th >Customer</th>
                                                <th >PostCode</th>
												<th >SKU</th>
												<th >QTY</th>
												<th >Shipping</th>
												<th >Total</th>
												<th ><div class="">Status</div></th>
											
												 <th ><div class="statuss">-</div></th>
												 
                                                
                                             </tr>
                                        </thead>
                                        <tbody>
										    <?php
						                       $sn=0;
											   
											 
											    $from_despatch = $_GET['from_despatch'];
											   $to_despatch = $_GET['to_despatch'];
											   $skuword_despatch = $_GET['skuword_despatch'];
											    $shippingword_despatch = $_GET['shippingword_despatch'];
						                     
											   if(!empty($from_despatch) or !empty($to_despatch)){
												$sql_0111=mysqli_query($conn,"SELECT * FROM `order_data` where status='shipped' AND `price` between '$from_despatch' AND '$to_despatch'");   
											   }elseif(!empty($skuword_despatch)){
												 $sql_0111=mysqli_query($conn,"SELECT * FROM `order_data` where status='shipped' AND CONCAT(UPPER(sku),UPPER(custom_label)) like UPPER('%$skuword_despatch%')");    
											   }elseif(!empty($shippingword_despatch)){
												   $sql_0111=mysqli_query($conn,"SELECT * FROM `order_data` WHERE `status`='shipped' AND CONCAT(UPPER(delivery_service),UPPER(ship_service_level)) LIKE UPPER('%$shippingword_despatch%') "); 
												  
											   }else{
												   $sql_0111=mysqli_query($conn,"SELECT * FROM `order_data` where status='shipped' ");  
											   }
						                      
						                       while($data_0111=mysqli_fetch_assoc($sql_0111))
						                       {
							                     $sn++;
							                     $id=$data_0111['id'];
							
							                     $name=$data_0111['name'];
		                                     ?>
                                             <tr class="odd gradeX">
                                               <td>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" name="company_order_id[]" value="<?php echo $id;?>" class="checkboxes"  />
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo $sn;?></td>
												<?php 
												
												$c_id = $data_0111['channel_id'];
												$c_name_data = mysqli_query($conn,"select * from `channel` where `id`='$c_id'");
												$data_c_name = mysqli_fetch_assoc($c_name_data);
												?>
                                                <td><img src="images/<?php echo $data_c_name['file'];?>" title="<?php echo $data_c_name['name'];?>" width="30px" height="30px"></td>
                                                <td  class=""><div class="tooltip1"><?php echo $data_0111['sales_r_no'];?><div class="">
												 <div class="portlet light">
												 <div class="row">
												 <div class="col-md-12 col-sm-12">
                                                        <div class="portlet yellow-crusta box">
                                                            <div class="portlet-title">
                                                                <div class="caption">
                                                                    <i class="fa fa-cogs"></i>Order Details </div>
                                                                
                                                            </div>
                                                            <div class="portlet-body">
                                                                <div class="row static-info">
                                                                    <center><div class="col-md-8 name">
																	
																	<h4>OrderNo.<?php echo $data_0111['sales_r_no'];?></h4>
																	</div>
                                                                   </center>
                                                                </div>
																<hr class="custome_hr">
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Date &amp; Time: </div>
                                                                    <div class="col-md-7 value"> Dec 27, 2013 7:16:25 PM </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Order Status: </div>
                                                                    <div class="col-md-7 value">
                                                                        <span class="label label-success"> Closed </span>
                                                                    </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Grand Total: </div>
                                                                    <div class="col-md-7 value"> $175.25 </div>
                                                                </div>
                                                                <div class="row static-info">
                                                                    <div class="col-md-5 name"> Payment Information: </div>
                                                                    <div class="col-md-7 value"> Credit Card </div>
                                                                </div>
																
                                                            </div>
                                                        </div>
                                                    </div>
												 </div>
												 </div>
												</div></div>
												</td>
                                                <td><?php  if(!empty($data_0111['sale_date'])){echo $data_0111['sale_date'];}else{echo $data_0111['payments_date'];}?></td>
												
                                                <td class=""><div class=""><?php if(!empty($data_0111['buyer_name'])){echo $data_0111['buyer_name'];} ?>
												</div>
												</td>
												
												
                                                
												<td >
												<div class=""><?php if(!empty($data_0111['buyer_postcode'])){echo $data_0111['buyer_postcode'];}else{echo $data_0111['ship_postal_code'];} ?></div>
												</td>
												<td><?php if(!empty($data_0111['custom_label'])){echo $data_0111['custom_label'];}else{echo $data_0111['sku'];} ?></td>
												 <td class=""><?php if(!empty($data_0111['quantity'])){echo $data_0111['quantity'];}else{echo $data_0111['quantity_to_ship'];} ?>
												
												</td>
												<td class=""><?php if(!empty($data_0111['delivery_service'])){echo $data_0111['delivery_service'];}else{echo $data_0111['ship_service_level'];} ?>
												
												</td>
												 <td>-</td>
												 <td> <?php if($data_0111['status']=='new') { ?>
											   <button type="button" class="label label-info">New</button>
											   <?php } elseif($data_0111['status']=='inprogress') { ?>
											    <button type="button" class="label label-warning">In progress</button>
											   <?php } elseif($data_0111['status']=='shipped' )  { ?>
											   <button type="button" class="label label-success">Shipped</button>
											   <?php } elseif($data_0111['status']=='close') { ?>
											    <button type="button" class="label label-danger">Close</button>
											   <?php } ?>
											   <br>
											   <?php if($data_0111['flag']=='holdorder') { ?>
											    <button type="button" class="label label-warning"> <span  class="icon-flag"></span>hold-order</button>
											   <?php }elseif($data_0111['flag']=='urgent'){ ?>
											    <button type="button" class="label label-danger"> <span  class="icon-flag"></span>urgent</button>
											   <?php } ?>
											   </td>
											   
												 <td> 
											  
																	<div class="btn-group ">
																	
                                                                      
                                                                        <button onclick="addUser(this.value);" value="<?php echo $id; ?>" type="button" class="fa fa-user green1" ></button>
                                                                      <button type="button" class="fa fa-edit notee"></button>
                                                                        <button type="button" class="fa fa-truck truck"></button>
																	
															
                                                                    </div><br>
																	<?php if(!empty($data_0111['user'])) { ?>
																	<button type="button" class="label label-warning"> <span  class="icon-user b11"></span>&nbsp;<span class="b11"><?php
																	$user_id =  $data_0111['user'];
																	$user_data1 = mysqli_query($conn,"select * from `user` where `uid`='$user_id'");
																			$data_user1 = mysqli_fetch_assoc($user_data1);
																			echo $data_user1['uname'];
																	?></span></button>
																	<?php } ?>
																	
																	</td>
                                               
                                                
                                               
                                               
                                              </tr>
                                            	  <?php  } ?>
                                        </tbody>
                                    </table>
									
									</form>
									
									<!-- tab 2 end--></div>
									<!-- tab 3 start-->
									
                                    </div>
                                    <!-- END EXAMPLE TABLE PORTLET-->
                                </div>
                                </div>
                            </div>
                           
                        </div>
                        <!-- END PAGE CONTENT INNER -->
                    </div>
                </div>
                <!-- END PAGE CONTENT BODY -->
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
           
            <!-- END QUICK SIDEBAR -->
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <!-- BEGIN PRE-FOOTER -->
        <?php include 'footer.php';?>
        <!-- END INNER FOOTER -->
        <!-- END FOOTER -->
        <!--[if lt IE 9]>
<script src="../assets/global/plugins/respond.min.js"></script>
<script src="../assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
		<script src="form.js" type="text/javascript"></script>
		<script src="custome.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="../assets/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="../assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="../assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="../assets/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="../assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="../assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="../assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
		<script>
		
</script>
<style>

</style>

        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html><?php
$filename = 'filename.html';
header('Content-disposition: attachment; filename=' . $filename);
header('Content-type: text/html');
// ... the rest of your file
?>