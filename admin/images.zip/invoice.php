<?php 
error_reporting(0);
include 'config.php';
session_start();
if($_SESSION['password']==""){
	echo "<script>window.location='login.php'</script>";
}
$company_order_id = $_POST['company_order_id'];

?>
<!DOCTYPE html>

<html dir="ltr" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Invoice</title>
<base href=".">
<link href="./Invoice_files/bootstrap.css" rel="stylesheet" media="all">
<script type="text/javascript" src="./Invoice_files/jquery-2.1.1.min.js.download"></script>
<script type="text/javascript" src="./Invoice_files/bootstrap.min.js.download"></script>
<link href="./Invoice_files/font-awesome.min.css" type="text/css" rel="stylesheet">
<link type="text/css" href="./Invoice_files/stylesheet.css" rel="stylesheet" media="all">
</head>
<?php
 $company_order_id1 = $company_order_id[0];
$order_data = mysqli_query($conn,"select * from `order_data` where `id`='$company_order_id1'");
$data_order = mysqli_fetch_assoc($order_data);

?>
<body cz-shortcut-listen="true">
<div class="container">
    <div style="page-break-after: always;">
   <br>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td colspan="2">Order Details</td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style="width: 50%;"><center><address>
            <strong><?php
			 $company_id = $data_order['company_id'];
			$company_name=  mysqli_query($conn,"select * from `company` where `id`='$company_id'");
			$name_company  = mysqli_fetch_assoc($company_name);
			echo $name_company['name'];
			?></strong><br>
             RV Packaging Ltd.<br>Unit 7 Carlton court<br>1 Grainger road<br>Southend-on-sea<br>Essex<br>SS2 5BZ<br>United Kingdom
            </address>
            <b>VAT Registration No</b>  275632093<br>
            <b>Telephone</b> +44 1702 805 285<br>
                        <b>E-Mail</b> info@postage-solutions.co.uk<br>
            <b>Web Site:</b> <a href="https://postage-solutions.co.uk/">https://postage-solutions.co.uk/</a> </center></td>
          <td style="width: 50%;">
		  <center>
		  <b>Date Added</b> <?php echo $data_order['invoice_date'];?><br>
                        <b>Invoice ID:</b> <?php echo $data_order['sales_r_no'];?><br>
            
                        <b>Shipping Method</b> <?php if(empty($data_order['delivery_service'])){ echo $data_order['ship_service_level'];}else{echo $data_order['delivery_service'];}?><br></center>
            </td>
        </tr>
      </tbody>
    </table>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td style="width: 50%;"><b>Payment Address</b></td>
          <td style="width: 50%;"><b>Shipping Address</b></td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><address>
            <?php echo $data_order['buyer_address_1'];?><br><?php echo $data_order['buyer_address_2'];?>
            </address></td>
          <td><address>
            -
            </address></td>
        </tr>
      </tbody>
    </table>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td><b>Product</b></td>
         
          <td class="text-right"><b>Quantity</b></td>
          <td class="text-right"><b>Unit Price</b></td>
          <td class="text-right"><b>Total</b></td>
        </tr>
      </thead>
      <tbody>
                <tr>
          <td><?php echo $data_order['item_title'];?>
            </td>
         
          <td class="text-right"><?php echo $data_order['quantity'];?></td>
          <td class="text-right"><?php echo $data_order['sale_price'];?></td>
          <td class="text-right">-</td>
        </tr>
                                <tr>
          <td class="text-right" colspan="3"><b>Sub-Total</b></td>
          <td class="text-right">-</td>
        </tr>
                <tr>
          <td class="text-right" colspan="3"><b>Next Day Delivery</b></td>
          <td class="text-right">-</td>
        </tr>
               
                <tr>
          <td class="text-right" colspan="3"><b>VAT (20%)</b></td>
          <td class="text-right">-</td>
        </tr>
                <tr>
          <td class="text-right" colspan="3"><b>Total</b></td>
          <td class="text-right">-</td>
        </tr>
              </tbody>
    </table>
      </div>
  </div>

</body></html>