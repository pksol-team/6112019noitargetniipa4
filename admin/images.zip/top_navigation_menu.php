<ul class="nav pull-right">
	
	
			
				
<a class="brand" href="logout.php">
				Log Out</a>			
				</ul>





					<!-- END USER LOGIN DROPDOWN -->
				</ul>