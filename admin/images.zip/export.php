<?php
include 'config.php';
session_start();
if($_SESSION['password']==''){
	echo "<script>window.location='login.php'</script>";
}
$company_order_id = $_POST['company_order_id'];
$file=fopen("Export.csv","w+") or exit("Unable to open file!");





/********* Excel Header *********/

$header = "Buyer Full Name, Buyer Phone Number, Buyer Email, Buyer Address 1, Buyer Address 2, Buyer Town/City, Buyer Country";
fwrite($file, $header.PHP_EOL);

/*********  Header  end *********/

/********* Excel Data *********/


	
	
	 
                         $sql_01=mysqli_query($conn,"select * from `order_data` where `id` IN (" . implode(',', array_map('intval', $company_order_id)) .")");
						 while($data_01=mysqli_fetch_assoc($sql_01))
						 {
							$buyer_name =$data_01['buyer_name'];
							$buyer_phone=$data_01['buyer_phone'];
							$buyer_email=$data_01['buyer_email'];
							$buyer_address_1=$data_01['buyer_address_1'];
							$buyer_address_2=$data_01['buyer_address_2'];
							 if(empty($data_01['buyer_town'])){
								 $buyer_town =$data_01['ship_city'];
								 }else{
								$buyer_town =$data_01['buyer_town'];
									 }
							 if(empty($data_01['buyer_country'])){
								 $buyer_country=$data_01['ship_country'];
								 }else{
									 $buyer_country=$data_01['buyer_country'];
									 }
							

$header_data="$buyer_name,$buyer_phone,$buyer_email,$buyer_address_1,$buyer_address_2,$buyer_town,$buyer_country";
fwrite($file, $header_data.PHP_EOL);
						 }
/*********  Excel  Data end *********/

fclose($file);
header('Content-Disposition: attachment; filename=Export.csv');
header('Content-type: application/xls');
readfile("Export.csv");
unlink("Export.csv");	

exit;
?>
<?php 
echo "<script>window.location.href='userview.php'</script>";
?>