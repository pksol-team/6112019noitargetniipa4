<?php

for($i=0; $i<54; $i++){
	echo "'$"."data$i"."',";
}

?>