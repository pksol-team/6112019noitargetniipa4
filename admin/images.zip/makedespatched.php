<?php
include 'config.php';
session_start();
if($_SESSION['password']==''
){
	echo "<script>window.location='login.php'</script>";
}
$company_order_id = $_POST['company_order_id'];
$despatch = $_POST['despatch'];
foreach($company_order_id as $company_order_id1){
	mysqli_query($conn,"update `order_data` set `status`='$despatch' where `id`='$company_order_id1'");
}
echo "<script>window.location='new.php'</script>";
?>