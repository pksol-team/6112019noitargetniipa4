 <div class="page-header-menu">
                <div class="container-fluid">
                    <!-- BEGIN HEADER SEARCH BOX -->
                    <form class="search-form" action="page_general_search.html" method="GET">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search" name="query">
                            <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                        </div>
                    </form>
                    <!-- END HEADER SEARCH BOX -->
                    <!-- BEGIN MEGA MENU -->
                    <!-- DOC: Apply "hor-menu-light" class after the "hor-menu" class below to have a horizontal menu with white background -->
                    <!-- DOC: Remove data-hover="dropdown" and data-close-others="true" attributes below to disable the dropdown opening on mouse hover
					<li class="menu-dropdown classic-menu-dropdown active">
                                <a href="index.php"> Dashboard
                                    <span class="arrow"></span>
                                </a>
                                <ul class="dropdown-menu pull-left">
                                    <li class=" active">
                                        <a href="table.php" class="nav-link  active">
                                            <i class="icon-bar-chart"></i> Table
                                            <span class="badge badge-success">1</span>
                                        </a>
                                    </li>
                                    <li class=" ">
                                        <a href="new.php" class="nav-link  ">
                                            <i class="icon-bulb"></i> Order Data </a>
                                    </li>
                                    <li class=" ">
                                        <a href="dashboard_3.html" class="nav-link  ">
                                            <i class="icon-graph"></i> Dashboard 3
                                            <span class="badge badge-danger">3</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
					-->
                    <div class="hor-menu  ">
                        <ul class="nav navbar-nav">
                            <li class="menu-dropdown classic-menu-dropdown active">
                                <a href="index.php"> Dashboard
                                    <span class="arrow"></span>
                                </a>
                                
                            </li>
							<li class="menu-dropdown classic-menu-dropdown active">
                                <a href="channelview.php">Channel
                                    <span class="arrow"></span>
                                </a>
                                
                            </li>
                            <li class="menu-dropdown classic-menu-dropdown active">
                                <a href="companyview.php">Companies
                                    <span class="arrow"></span>
                                </a>
                                
                            </li>
                            <li class="menu-dropdown classic-menu-dropdown active">
                                <a href="c_order_view.php"> Orders
                                    <span class="arrow"></span>
                                </a>
                                
                            </li> 
							<li class="menu-dropdown classic-menu-dropdown active">
                                <a href="userview.php"> Add User
                                    <span class="arrow"></span>
                                </a>
                                
                            </li> 
							
                            
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- END MEGA MENU -->
                </div>
            </div>