	
									function FormStuffProgress() {
									
									var print_type_progress = document.getElementById("print_type_progress").value;
										if(print_type_progress == 'invoice'){
									 document.print_progress.action = "invoice.php";
									 document.getElementById("selectstatus1").innerHTML = "";	
									
										}else if(print_type_progress == 'picking'){
											
										 document.print_progress.action = "picking_list.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}
										else if(print_type_progress == 'returnsform'){
											
										 document.print_progress.action = "returnsform.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}
										
										else if(print_type_progress == 'addnote'){
											
										 document.print_progress.action = "addnotesubmit.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
								 $('#selectstatus1').append('<input name="addnote" placeholder="Enter Note Here" type="text" class="form-control selectst"><br>');
										}
										else if(print_type_progress == 'export'){
											
										 document.print_progress.action = "export.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}
										
										else if(print_type_progress == 'flag'){
											
										 document.print_progress.action = "flagsubmit.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
										 $('#selectstatus1').append('<select name="flag" type="text" class="form-control selectst"><option value="">Select Flag Status</option><option value="holdorder">Hold Order</option><option value="urgent">Urgent</option></select><br>');
										}
										
										
										else if(print_type_progress == 'jobsheet'){
											
										 document.print_progress.action = "jobsheet.php";
										
								document.getElementById("selectstatus1").innerHTML = "";										
										}else if(print_type_progress == 'makedespatched'){
											
										 document.print_progress.action = "makedespatched.php";
										
								document.getElementById("selectstatus1").innerHTML = "";
										 $('#selectstatus1').append('<select name="despatch" type="text" class="form-control selectst"><option value="">Select Status</option><option value="0">Remove As Despatched</option><option value="shipped">Make As Despatced</option></select><br>');
										}
										
										else if(print_type_progress == 'status'){
											
										 document.print_progress.action = "status_change.php";
										 document.getElementById("selectstatus1").innerHTML = "";
										  $('#selectstatus1').append('<select name="status" type="text" class="form-control selectst"><option value="">Select Status</option><option value="new">New</option><option value="inprogress">In progress</option><option value="shipped">Shipped</option ><option value="close">Close</option></select><br>');
																		
										}
										else{
											document.print_progress.action = "#";
											document.getElementById("selectstatus1").innerHTML = "";	
										}
									}
									