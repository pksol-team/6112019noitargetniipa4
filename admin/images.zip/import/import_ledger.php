<?php


 $allowed =  array('xlsb','xlsx','xls','xlm','xlt','xlsm','xltx','xltm','xla','xlsb','xll','xlam','xlw','csv');
$filename1 = $_FILES['file']['name'];
$ext = pathinfo($filename1, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    echo "<script>window.location='../dispatchsummaryview.php'; alert('not valied file!');</script>";
}

error_reporting(0);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');




/** Include PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/Classes/PHPExcel/IOFactory.php';


$objPHPExcel = $_FILES['file']['tmp_name'];

    if(!file_exists($objPHPExcel))
	{
		$error='File Not Found';
		printf("<script>location.href='index.php?message=$error'</script>");
		exit;	
    }	
    $file = fopen($objPHPExcel,"r");
	chmod($objPHPExcel,0777);
	if(!$file)
	{
		echo "Error opening data file.\n";
		exit;
    }
$allowed =  array('xls','csv','xlsx');
$filename = $_FILES['file']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    echo 'Invalid File';
	exit;
}


$inputFileName = $_FILES['file']['tmp_name'];

//  Read your Excel workbook
try {
    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
    $objPHPExcel = $objReader->load($inputFileName);
} catch(Exception $e) {
    die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}

//  Get worksheet dimensions
$sheet = $objPHPExcel->getSheet(0); 
$highestRow = $sheet->getHighestRow(); 
$highestColumn = $sheet->getHighestColumn();
include("config.php");
//  Loop through each row of the worksheet in turn
for ($row = 1; $row <= $highestRow; $row++){ 
    //  Read a row of data into an array
	
	if($row==1)
	{
		continue;
	}
    $rowData1 = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                    NULL,
                                    TRUE,
                                    FALSE);
									
				$rowData=$rowData1[0];				




$date = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($rowData[0]));	





$billno=$rowData[1];
$vno=$rowData[2];

$reference = $rowData[3];
$debitamt=$rowData[4];
$creditamt=$rowData[5];
$balance=$rowData[6];
$remark=$rowData[7];

$gnumber=$rowData[8];
$suppliergstno=$rowData[9];

        mysqli_query($conn,"INSERT INTO `ledger`(`date`, `billno`, `vno`, `reference`, `debitamt`, `creditamt`, `balance`, `remark`, `gnumber`,`suppliergstno`) VALUES ('$date', '$billno', '$vno', '$reference', '$debitamt', '$creditamt', '$balance', '$remark', '$gnumber','$suppliergstno')");
	


}

echo "<script>window.location='../ledgerview.php'</script>";