<?php


 $allowed =  array('xlsb','xlsx','xls','xlm','xlt','xlsm','xltx','xltm','xla','xlsb','xll','xlam','xlw','csv');
$filename1 = $_FILES['file']['name'];
$ext = pathinfo($filename1, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    echo "<script>window.location='../buyerview.php'; alert('not valied file!');</script>";
}

error_reporting(0);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');




/** Include PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/Classes/PHPExcel/IOFactory.php';


$objPHPExcel = $_FILES['file']['tmp_name'];

    if(!file_exists($objPHPExcel))
	{
		$error='File Not Found';
		printf("<script>location.href='index.php?message=$error'</script>");
		exit;	
    }	
    $file = fopen($objPHPExcel,"r");
	chmod($objPHPExcel,0777);
	if(!$file)
	{
		echo "Error opening data file.\n";
		exit;
    }
$allowed =  array('xls','csv','xlsx');
$filename = $_FILES['file']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
	unlink($filename);
    echo 'Invalid File';
	exit;
}


$inputFileName = $_FILES['file']['tmp_name'];

//  Read your Excel workbook
try {
    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
    $objPHPExcel = $objReader->load($inputFileName);
} catch(Exception $e) {
    die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}

//  Get worksheet dimensions
$sheet = $objPHPExcel->getSheet(0); 
$highestRow = $sheet->getHighestRow(); 
$highestColumn = $sheet->getHighestColumn();
include("config.php");
//  Loop through each row of the worksheet in turn
for ($row = 1; $row <= $highestRow; $row++){ 
    //  Read a row of data into an array
	
	if($row==1)
	{
		continue;
	}
    $rowData1 = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                    NULL,
                                    TRUE,
                                    FALSE);
									
				$rowData=$rowData1[0];				



//echo date_format($date,"Y/m/d H:i:s");
$company_id = $_POST['company_id'];
$data0=$rowData[0];
$data1=$rowData[1];
$data2=date('d-m-Y H:i:s', strtotime($rowData[2]));
$data3=date('d-m-Y H:i:s', strtotime($rowData[3]));
$data4=date('d-m-Y H:i:s', strtotime($rowData[4]));
$data5=date('d-m-Y H:i:s', strtotime($rowData[5]));
$data6=$rowData[6];
$data7=$rowData[7];
$data8=$rowData[8];
$data9=$rowData[9];
$data10=$rowData[10];
$data11=$rowData[11];
$data12=$rowData[12];
$data13=$rowData[13];
$data14=$rowData[14];
$data15=$rowData[15];
$data16=$rowData[16];
$data17=$rowData[17];
$data18=$rowData[18];
$data19=$rowData[19];
$data20=$rowData[20];
$data21=$rowData[21];
$data22=$rowData[22];
$data23=$rowData[23];
$data24=$rowData[24];
$data25=$rowData[25];
$data26=$rowData[26];
		
		$check_o_id = mysqli_query($conn,"select * from `company_order_data` where `order_id`='$data0'");
		$data_ceck_o = mysqli_fetch_assoc($check_o_id);
		if($data_ceck_o['order_id'] == $data0){
			echo "already stored!"."<br>";
		}else{
		
    
  mysqli_query($conn,"INSERT INTO `company_order_data`( `company_id`, `order_id`, `order_item_id`, `purchase_date`, `payments_date`, `reporting_date`, `promise_date`, `days_past_promise`, `buyer_email`, `buyer_name`, `buyer_number`, `sku`, `product_name`, `quantity_purchased`, `quantity_shipped`, `quantity_to_ship`, `ship_service_level`, `recipient_name`, `ship_address_1`, `ship_address_2`, `ship_address_3`, `ship_city`, `ship_state`, `ship_postal_code`, `ship_country`, `is_business_order`, `purchase_order_no`, `price_designation`) VALUES ('$company_id','$data0','$data1','$data2','$data3','$data4','$data5','$data6','$data7','$data8','$data9','$data10','$data11','$data12','$data13','$data14','$data15','$data16','$data17','$data18','$data19','$data20','$data21','$data22','$data23','$data24','$data25','$data26')");
	
		}
}
echo "<script>window.location='../c_order.php'</script>";