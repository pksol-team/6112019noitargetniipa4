
<form method="post" action="import_data.php" enctype="multipart/form-data">
<b>Upload Excel File</b> <br>

<input type="file" name="import_file"><br>
<br>
<input type="submit" value="Submit" >
<br>
<br>
<a href="http://amaviexpo.in/sample.xlsx" target="_blnak">Download Sample</a>
</form>
