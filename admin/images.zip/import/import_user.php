<?php


 $allowed =  array('xlsb','xlsx','xls','xlm','xlt','xlsm','xltx','xltm','xla','xlsb','xll','xlam','xlw','csv');
$filename1 = $_FILES['file']['name'];
$ext = pathinfo($filename1, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    echo "<script>window.location='../dispatchsummaryview.php'; alert('not valied file!');</script>";
}

error_reporting(0);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');




/** Include PHPExcel_IOFactory */
require_once dirname(__FILE__) . '/Classes/PHPExcel/IOFactory.php';


$objPHPExcel = $_FILES['file']['tmp_name'];

    if(!file_exists($objPHPExcel))
	{
		$error='File Not Found';
		printf("<script>location.href='index.php?message=$error'</script>");
		exit;	
    }	
    $file = fopen($objPHPExcel,"r");
	chmod($objPHPExcel,0777);
	if(!$file)
	{
		echo "Error opening data file.\n";
		exit;
    }
$allowed =  array('xls','csv','xlsx');
$filename = $_FILES['file']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
    echo 'Invalid File';
	exit;
}


$inputFileName = $_FILES['file']['tmp_name'];

//  Read your Excel workbook
try {
    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
    $objPHPExcel = $objReader->load($inputFileName);
} catch(Exception $e) {
    die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}

//  Get worksheet dimensions
$sheet = $objPHPExcel->getSheet(0); 
$highestRow = $sheet->getHighestRow(); 
$highestColumn = $sheet->getHighestColumn();
include("config.php");
//  Loop through each row of the worksheet in turn
for ($row = 1; $row <= $highestRow; $row++){ 
    //  Read a row of data into an array
	
	if($row==1)
	{
		continue;
	}
    $rowData1 = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                    NULL,
                                    TRUE,
                                    FALSE);
									
				$rowData=$rowData1[0];				



echo date_format($date,"Y/m/d H:i:s");
$usertype=$rowData[0];

$fname=$rowData[1];

$gnumber=$rowData[2];

$oname = $rowData[3];

$password=$rowData[4];
$mno2=$rowData[5];
$mno3=$rowData[6];
$mno4=$rowData[7];
$lenline1=$rowData[8];
$lenline2=$rowData[9];
$lenline3 = $rowData[10];
$lenline4=$rowData[11];
$address=$rowData[12];
$email1=$rowData[13];
$email2=$rowData[14];
$transport=$rowData[15];
$place=$rowData[16];
$remark=$rowData[17];

 if($usertype==''){
	echo "<script>alert('not valied user..$fname');</script>";
}else{
$gnumberserch = mysqli_query($conn,"select * from `user` where `gnumber`='$gnumber'");
$searchgnumber = mysqli_fetch_assoc($gnumberserch);
$serched_gst_number = $searchgnumber['gnumber']; 
if($gnumber==$serched_gst_number){
echo "<script>alert('user updated!');</script>";
mysqli_query($conn,"update user set `usertype`='$usertype',`fname`='$fname',  `oname`='$oname', `password`='$password', `mno2`='$mno2', `mno3`='$mno3', `mno4`='$mno4', `lenline1`='$lenline1', `lenline2`='$lenline2', `lenline3`='$lenline3', `lenline4`='$lenline4', `address`='$address', `email1`='$email1', `email2`='$email2', `transport`='$transport', `place`='$place', `remark`='$remark' where `gnumber`='$gnumber'");	

}else{
	
mysqli_query($conn,"INSERT INTO `user`(`usertype`, `fname`, `gnumber`, `oname`, `password`, `mno2`, `mno3`, `mno4`, `lenline1`, `lenline2`, `lenline3`, `lenline4`, `address`, `email1`, `email2`, `transport`, `place`, `remark`) VALUES ('$usertype','$fname','$gnumber','$oname','$password','$mno2','$mno3','$mno4','$lenline1','$lenline2','$lenline3','$lenline4','$address','$email1','$email2','$transport','$place','$remark')");
}

}
}

echo "<script>window.location='../userview.php'</script>";