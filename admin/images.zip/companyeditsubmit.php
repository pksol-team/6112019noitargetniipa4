<?php include 'config.php';

session_start();

	if($_SESSION['password']=="")
	
	{
		echo "<script>window.location='login.php?msg=please login'</script>";
	}
	
$id=$_REQUEST['id'];


$name=$_POST['name'];
mysqli_query($conn,"update `company` set `name`='$name' where `id`='$id'");

mysqli_query($conn,"delete from `company_data`  where `company_id`='$id'");
$channelname = $_POST['channelname'];
foreach($channelname as $channelname1){
	mysqli_query($conn,"insert into `company_data` (`company_id`,`channel_name`)values('$id','$channelname1')");
}

echo "<script>window.location='companyview.php'</script>";

?>